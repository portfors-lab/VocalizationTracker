% BSP File Import Functions
% Version 1.00 JM Jun-2002
%
%   HolterRead - Reads Holter ECG data
