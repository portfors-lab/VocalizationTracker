% BSP Signal Models
% Version 2.00 JM Jul-2002
%
%   Approximate Entropy     - Calculates the approximate Entropy of a signal.
%   MAInnovations           - Estimate the moving average process parameters.
