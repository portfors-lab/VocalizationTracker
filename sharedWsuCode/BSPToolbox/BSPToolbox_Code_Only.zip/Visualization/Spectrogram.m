function [S,t,f] = Spectrogram(x,fsa,wla,fra,nfa,nsa,pfa)

fprintf('Spectrogram has been replaced with the function NonparametricSpectrogram.\n');
