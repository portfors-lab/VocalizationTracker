function display(sb)

disp(sb.a)
% fn = fieldnames(sb);
% for(c1 = 1:length(fn))
%     eval(['disp(sb.' fn(c1) ')']);
% end