function nh = updateHandle(sb)
%this function will update the object
nh = get(sb.a, 'userdata');
