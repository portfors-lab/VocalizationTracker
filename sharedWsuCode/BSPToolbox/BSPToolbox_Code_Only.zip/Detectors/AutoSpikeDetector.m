function [id]=AutoSpikeDetector(xa,fsa,kwpa,detecta,pfa);
% AutoSpikeDetector: Obsolete. Replaced with DetectSpikesTemplate.

fprintf('This function has been replaced with SpikeDetectTemplate\n');