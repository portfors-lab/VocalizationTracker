function [TE,TP,FP,FN,TNS]=TotalError(fsa,dida,tida,aia);
%TotalError:Obsolete. See DetectionErrorIndices.

fprintf('This function has been replaced with the function DetectionErrorIndices.\n');